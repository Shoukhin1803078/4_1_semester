#include<stdio.h>
int main()
{
    int a,b,c;
   
    b=10;
    c=20;
    a=b+c;
    printf("a=%d\n",a);

}