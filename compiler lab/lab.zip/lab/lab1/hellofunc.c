#include<stdio.h>
#include "hellomake.h"

void myPringHelloMake()
{
    printf("hello this is hellofunc");
}