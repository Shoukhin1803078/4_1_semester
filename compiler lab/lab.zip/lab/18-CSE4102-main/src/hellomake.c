#include "hellomake.h"

int main()
{
    myPrintHelloMake();
    return 0;
}