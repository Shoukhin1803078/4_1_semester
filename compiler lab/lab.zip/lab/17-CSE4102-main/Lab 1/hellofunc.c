#include<stdio.h>
#include<hellomake.h>

void myPrintHelloMake()
{
    printf("My Print Hello Make 23\n");
}